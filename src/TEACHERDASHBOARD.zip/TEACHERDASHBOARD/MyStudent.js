import React from 'react'
import Create_Student from '../components/Student/Create_Student';
// import Create_Student from './Create_Student';
const MyStudent = () => {
  return (
  <>
   <Create_Student/>
  </>
  )
}

export default MyStudent