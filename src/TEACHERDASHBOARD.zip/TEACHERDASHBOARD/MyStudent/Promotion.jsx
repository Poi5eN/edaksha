import React from 'react'
import Create_Promotion from './Create_Promotion'

const Promotion = () => {
  return (
    <div>
      <Create_Promotion/>
    </div>
  )
}

export default Promotion
